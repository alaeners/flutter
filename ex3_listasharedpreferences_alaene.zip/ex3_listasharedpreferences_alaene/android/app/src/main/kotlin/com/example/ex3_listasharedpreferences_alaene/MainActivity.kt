package com.example.ex3_listasharedpreferences_alaene

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
