package com.example.ex4_listatarefas_alaene

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
